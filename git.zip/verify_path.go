package uscease

import (
	"cliperso/pkg/utils"
	"os"
)

func VerifyPath() utils.Log {
	path := "/usr/share/themes/"

	info, err := os.Stat(path)
	if os.IsNotExist(err) {
		return utils.Log{
			Error: true,
			Body: map[string]any{
				"message": "[ERROR] Pasta inexistente.",
			},
		}
	}
	if info.IsDir() {
		return utils.Log{
			Error: false,
			Body: map[string]any{
				"message": "[SUCESS] Pasta existente.",
			},
		}
	} else {
		return utils.Log{
			Error: true,
			Body: map[string]any{
				"message": "[ERROR] Caminho existente, mas nao e uma pasta.",
			},
		}
	}
}
