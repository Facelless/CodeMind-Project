package infra

import (
	"cliperso/pkg/utils"
	"os/exec"
)

func Clone(repoURL, destination string) utils.Log {
	cmd := exec.Command("git", "clone", repoURL, destination)
	err := cmd.Run()
	if err != nil {
		return utils.Log{
			Error: true,
			Body: map[string]any{
				"message": "[ERROR] Erro ao executar git clone",
			},
		}
	}
	return utils.Log{
		Error: false,
		Body: map[string]any{
			"message": "[SUCESS] Repositorio clonado",
		},
	}
}
